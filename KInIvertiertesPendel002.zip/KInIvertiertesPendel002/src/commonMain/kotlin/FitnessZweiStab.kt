import kotlin.math.cos
import kotlin.math.pow

fun fitnessFunktion2(netz : Netzwerk,geschwindigkeitsInformationen:Boolean):Double {

    /** testen, ob Netztopologie an Aufgabe angepasst ist **/
if((netz.schichten[0]!=3&&!geschwindigkeitsInformationen)||(netz.schichten[0]!=6&&geschwindigkeitsInformationen)){
    error("falsche Netztopologie: " +
            "mit Geschwindigkeitsinformationen: 6 Inputs und 1 Output, " +
            "ohne Geschwindigkeitsinformationen: 3 Inputs und 1 Output")
}

    var zeit = 0.0
    val zeitschritt= 0.02
    val g= 9.81

    /**Reibungscoeffizient der Achse, welche Wagen und Stab verbindet**/
    val stabReibung =0.000002
    /**reibungscoeffizient zwischen Wagen und Boden**/
    val reibungscoeffizient= 0.0005

    /**Abbruchkriterien**/
    val streckenGrenze = 2.4
    val drehGrenze = 36.0

    /**vom Netzwerk ausgeübte Kraft*/
    val kraft = 10.0

    /**Initialwerte des Wagens**/
    var wagenX =0.0
    var wagenV =0.0
    var wagenA= 0.0
    val wagenMasse= 1.0


    /**Initialwerte des ersten Stabs**/
    var stabRotation= 1.0
    var stabWinkelgeschwindigkeit=0.0
    var stabWinkelbeschleunigung = 0.0
    val stabMasse= 0.1
    val stabHalbeLaenge= 0.5
    var stabEffektiveMasse= stabMasse*(1-(3/4)*cos(stabRotation).pow(2))
    var stabEffektiveKraft=stabEffektiveKraft(stabMasse,stabHalbeLaenge,stabWinkelgeschwindigkeit,stabRotation,stabReibung,g)


    /**Initialwerte des zweiten Stabs**/
    var stab2Rotation= 0.0
    var stab2Winkelgeschwindigkeit=0.0
    var stab2Winkelbeschleunigung = 0.0
    val stab2Masse= 0.01
    val stab2HalbeLaenge= 0.05
    var stab2EffektiveMasse= stab2Masse*(1-(3/4)*cos(stab2Rotation).pow(2))
    var stab2EffektiveKraft=stabEffektiveKraft(stab2Masse,stab2HalbeLaenge,stab2Winkelgeschwindigkeit,stab2Rotation,stabReibung,g)



    var aBewegungen=0
    /**Der Versuch wird so lange simuliert, bis die Abbruchkriterien überschritten werden**/
    while(wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && stab2Rotation<drehGrenze && stab2Rotation>-drehGrenze && aBewegungen<100000) {
        /** bevor die Werte dem Netz gegeben werden werden sie auf [-1;1] normiert**/
        val wagenXtmp = wagenX/2.4
        val wagenVtmp=wagenV/6.6
        val stabRotationtmp=stabRotation/36.0
        val stabWinkelgeschwindigkeittmp=stabWinkelgeschwindigkeit/10
        val stab2Rotationtmp=stab2Rotation/36.0
        val stab2Winkelgeschwindigkeittmp = stab2Winkelgeschwindigkeit/10

        var angewendeteKraft: Double
        var output:DoubleArray

        /**Hier wird unterschieden ob der Versuch mit oder ohne Geschwindigkeitsinformationen gefragt ist**/
        if(geschwindigkeitsInformationen){
            output = netz.rechnen(
                doubleArrayOf(
                    wagenXtmp,
                    wagenVtmp,
                    stabRotationtmp,
                    stabWinkelgeschwindigkeittmp,
                    stab2Rotationtmp,
                    stab2Winkelgeschwindigkeittmp
                )
            )
        }
        else{
            output = netz.rechnen(
                doubleArrayOf(
                    wagenXtmp,
                    stabRotationtmp,
                    stab2Rotationtmp,
                )
            )
        }
        /** Abhängig vom Output  erhält die Kraft den Vorfaktor + oder - **/
        if (output[0] == 0.0) angewendeteKraft = kraft
        else angewendeteKraft = -kraft

        /** Runge-Kutta Verfahren 4.Ordnung
         * die Werte für den Nächsten Zeitschritt werden Berechnet**/
        var xTmp = 0.0
        var vTmp: Double
        var rot1Tmp: Double
        var rot2Tmp: Double
        var vRot1Tmp: Double
        var vRot2Tmp: Double

        /**1. Schritt**/
        var stabEffektiveKraft1 = stabEffektiveKraft(stabMasse, stabHalbeLaenge, stabWinkelgeschwindigkeit, stabRotation, stabReibung, g)
        var stab2EffektiveKraft1 = stabEffektiveKraft(stab2Masse, stab2HalbeLaenge, stab2Winkelgeschwindigkeit, stab2Rotation, stabReibung, g)
        var stabEffektiveMasse1 = stabEffektiveMasse(stabMasse, stabRotation)
        var stab2EffektiveMasse1 = stabEffektiveMasse(stab2Masse, stab2Rotation)
        var wagenA1 = beschleunigung(angewendeteKraft, reibungscoeffizient, wagenV, stab2EffektiveKraft1, stabEffektiveKraft1, wagenMasse, stab2EffektiveMasse1, stabEffektiveMasse1)
        var stabWinkelbeschleunigung1 = winkelbeschleunigung(stabHalbeLaenge, wagenA1, stabRotation, g, stabReibung, stabWinkelgeschwindigkeit, stabMasse)
        var stab2Winkelbeschleunigung1 = winkelbeschleunigung(stab2HalbeLaenge, wagenA1, stab2Rotation, g, stabReibung, stab2Winkelgeschwindigkeit, stab2Masse)
        var wagenV1 = wagenV
        var stabWinkelgeschwindigkeit1 = stabWinkelgeschwindigkeit
        var stab2Winkelgeschwindigkeit1 = stab2Winkelgeschwindigkeit


        xTmp = wagenX + 0.5 * zeitschritt * wagenV1
        vTmp = wagenV + 0.5 * zeitschritt * wagenA1

        rot1Tmp = stabRotation + 0.5 * zeitschritt * stabWinkelgeschwindigkeit1
        vRot1Tmp = stabWinkelgeschwindigkeit + 0.5 * zeitschritt * stabWinkelbeschleunigung1

        rot2Tmp = stab2Rotation + 0.5 * zeitschritt * stab2Winkelgeschwindigkeit1
        vRot2Tmp = stab2Winkelgeschwindigkeit + 0.5 * zeitschritt * stab2Winkelbeschleunigung1

        /**2. Schritt**/
        var stabEffektiveKraft2 = stabEffektiveKraft(stabMasse, stabHalbeLaenge, vRot1Tmp, rot1Tmp, stabReibung, g)
        var stab2EffektiveKraft2 = stabEffektiveKraft(stab2Masse, stab2HalbeLaenge, vRot2Tmp, rot2Tmp, stabReibung, g)
        var stabEffektiveMasse2 = stabEffektiveMasse(stabMasse, rot1Tmp)
        var stab2EffektiveMasse2 = stabEffektiveMasse(stab2Masse, rot2Tmp)
        var wagenA2 = beschleunigung(angewendeteKraft, reibungscoeffizient, vTmp, stab2EffektiveKraft2, stabEffektiveKraft2, wagenMasse, stab2EffektiveMasse2, stabEffektiveMasse2)
        var stabWinkelbeschleunigung2 =
            winkelbeschleunigung(stabHalbeLaenge, wagenA2, rot1Tmp, g, stabReibung, vRot1Tmp, stabMasse)
        var stab2Winkelbeschleunigung2 = winkelbeschleunigung(stab2HalbeLaenge, wagenA2, rot2Tmp, g, stabReibung, vRot2Tmp, stab2Masse)
        var wagenV2 = vTmp
        var stabWinkelgeschwindigkeit2 = vRot1Tmp
        var stab2Winkelgeschwindigkeit2 = vRot2Tmp


        xTmp = wagenX + 0.5 * zeitschritt * wagenV2
        vTmp = wagenV + 0.5 * zeitschritt * wagenA2

        rot1Tmp = stabRotation + 0.5 * zeitschritt * stabWinkelgeschwindigkeit2
        vRot1Tmp = stabWinkelgeschwindigkeit + 0.5 * zeitschritt * stabWinkelbeschleunigung2

        rot2Tmp = stab2Rotation + 0.5 * zeitschritt * stab2Winkelgeschwindigkeit2
        vRot2Tmp = stab2Winkelgeschwindigkeit + 0.5 * zeitschritt * stab2Winkelbeschleunigung2

        /**3. Schritt**/
        var stabEffektiveKraft3 = stabEffektiveKraft(stabMasse, stabHalbeLaenge, vRot1Tmp, rot1Tmp, stabReibung, g)
        var stab2EffektiveKraft3 = stabEffektiveKraft(stab2Masse, stab2HalbeLaenge, vRot2Tmp, rot2Tmp, stabReibung, g)
        var stabEffektiveMasse3 = stabEffektiveMasse(stabMasse, rot1Tmp)
        var stab2EffektiveMasse3 = stabEffektiveMasse(stab2Masse, rot2Tmp)
        var wagenA3 = beschleunigung(angewendeteKraft, reibungscoeffizient, vTmp, stab2EffektiveKraft3, stabEffektiveKraft3, wagenMasse, stab2EffektiveMasse3, stabEffektiveMasse3)
        var stabWinkelbeschleunigung3 = winkelbeschleunigung(stabHalbeLaenge, wagenA3, rot1Tmp, g, stabReibung, vRot1Tmp, stabMasse)
        var stab2Winkelbeschleunigung3 = winkelbeschleunigung(stab2HalbeLaenge, wagenA3, rot2Tmp, g, stabReibung, vRot2Tmp, stab2Masse)
        var wagenV3 = vTmp
        var stabWinkelgeschwindigkeit3 = vRot1Tmp
        var stab2Winkelgeschwindigkeit3 = vRot2Tmp


        xTmp = wagenX + zeitschritt * wagenV3
        vTmp = wagenV + zeitschritt * wagenA3

        rot1Tmp = stabRotation + zeitschritt * stabWinkelgeschwindigkeit3
        vRot1Tmp = stabWinkelgeschwindigkeit + zeitschritt * stabWinkelbeschleunigung3

        rot2Tmp = stab2Rotation + zeitschritt * stab2Winkelgeschwindigkeit3
        vRot2Tmp = stab2Winkelgeschwindigkeit + zeitschritt * stab2Winkelbeschleunigung3

        /**4. Schritt**/
        var stabEffektiveKraft4 = stabEffektiveKraft(stabMasse, stabHalbeLaenge, vRot1Tmp, rot1Tmp, stabReibung, g)
        var stab2EffektiveKraft4 = stabEffektiveKraft(stab2Masse,
            stab2HalbeLaenge, vRot2Tmp, rot2Tmp, stabReibung, g)
        var stabEffektiveMasse4 = stabEffektiveMasse(stabMasse, rot1Tmp)
        var stab2EffektiveMasse4 = stabEffektiveMasse(stab2Masse, rot2Tmp)
        var wagenA4 = beschleunigung(angewendeteKraft, reibungscoeffizient, vTmp, stab2EffektiveKraft4, stabEffektiveKraft4, wagenMasse, stab2EffektiveMasse4, stabEffektiveMasse4)
        var stabWinkelbeschleunigung4 = winkelbeschleunigung(stabHalbeLaenge, wagenA4, rot1Tmp, g, stabReibung, vRot1Tmp, stabMasse)
        var stab2Winkelbeschleunigung4 = winkelbeschleunigung(stab2HalbeLaenge, wagenA4, rot2Tmp, g, stabReibung, vRot2Tmp, stab2Masse)
        var wagenV4 = vTmp
        var stabWinkelgeschwindigkeit4 = vRot1Tmp
        var stab2Winkelgeschwindigkeit4 = vRot2Tmp


        wagenV += (wagenA1 + (wagenA2 + wagenA3) * 2.0 + wagenA4) * zeitschritt / 6.0
        wagenX += (wagenV1 + (wagenV2 + wagenV3) * 2.0 + wagenV4) * zeitschritt / 6.0
        stabRotation += (stabWinkelgeschwindigkeit1 + (stabWinkelgeschwindigkeit2 + stabWinkelgeschwindigkeit3) * 2.0 + stabWinkelgeschwindigkeit4) * zeitschritt / 6.0
        stab2Rotation += (stab2Winkelgeschwindigkeit1 + (stab2Winkelgeschwindigkeit2 + stab2Winkelgeschwindigkeit3) * 2.0 + stab2Winkelgeschwindigkeit4) * zeitschritt / 6.0
        stabWinkelgeschwindigkeit += (stabWinkelbeschleunigung1 + (stabWinkelbeschleunigung2 + stabWinkelbeschleunigung3) * 2.0 + stabWinkelbeschleunigung4) * zeitschritt / 6.0
        stab2Winkelgeschwindigkeit += (stab2Winkelbeschleunigung1 + (stab2Winkelbeschleunigung2 + stab2Winkelbeschleunigung3) * 2.0 + stab2Winkelbeschleunigung4) * zeitschritt / 6.0
        aBewegungen+=1
        zeit += zeitschritt


    }

        netz.fitness = aBewegungen.toDouble()
        return aBewegungen.toDouble()

}

