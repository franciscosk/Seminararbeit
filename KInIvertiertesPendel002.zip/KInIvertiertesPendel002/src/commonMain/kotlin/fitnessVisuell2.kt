
import com.soywiz.klock.TimeSpan
import com.soywiz.korge.Korge
import com.soywiz.korge.box2d.registerBodyWithFixture
import com.soywiz.korge.view.*
import com.soywiz.korim.color.Colors
import com.soywiz.korio.async.delay
import com.soywiz.korma.geom.Angle
import org.jbox2d.dynamics.BodyType
import kotlin.math.*

/** stage aufbauen, auf der der Versuch visualisiert wird**/
suspend fun fitness2Visuell(netze: Array<Netzwerk>, geschwindigkeitsInformationen:Boolean)  =  Korge(width = 1920, height = 1080, bgcolor = Colors["#2b2b2b"]){
var generation=0
    for( netz in netze) {
        generation++
     macheNetzMagie2(netz, this, generation,  geschwindigkeitsInformationen)



}

}
/**ermittelt, wie lange ein übergebenes Netz simultan zwei Stäbe balancieren kann, und visualisiert den Versuch**/
suspend fun macheNetzMagie2(netz : Netzwerk, stage: Stage, generation: Int, geschwindigkeitsInformationen: Boolean) {

    /** testen, ob Netztopologie an Aufgabe angepasst ist **/
    if((netz.schichten[0]!=3&&!geschwindigkeitsInformationen)||(netz.schichten[0]!=6&&geschwindigkeitsInformationen)){
        error("falsche Netztopologie: " +
                "mit Geschwindigkeitsinformationen: 6 Inputs und 1 Output, " +
                "ohne Geschwindigkeitsinformationen: 3 Inputs und 1 Output")
    }


    var zeit = 0.0
    val zeitschritt= 0.02
    val g= 9.81

    /**Reibungscoeffizient der Achse, welche Wagen und Stab verbindet**/
    val stabReibung =0.000002
    /**reibungscoeffizient zwischen Wagen und Boden**/
    val reibungscoeffizient= 0.0005

   /**Abbruchkriterien**/
    val streckenGrenze = 2.4
    val drehGrenze = 36.0/180.0*PI

    /**vom Netzwerk ausgeübte Kraft*/
    val kraft = 10.0

    /**Initialwerte des Wagens**/
    var wagenX =0.0
    var wagenV =0.0
    val wagenMasse= 1.0


    /**Initialwerte des ersten Stabs**/
    var stabRotation= 1.0/180.0*PI
    var stabWinkelgeschwindigkeit=0.0
    val stabMasse= 0.1
    val stabHalbeLaenge= 0.5

    /**Initialwerte des zweiten Stabs**/
    var stab2Rotation= 0.0
    var stab2Winkelgeschwindigkeit=0.0
    val stab2Masse= 0.01
    val stab2HalbeLaenge= 0.05



    /**Zur besseren Visualisierung werden die Werte vergrößert **/
    val vergroesserungsFaktor = 400
    val hoeheStab=vergroesserungsFaktor*stabHalbeLaenge
    val breiteStab=hoeheStab/20
    val hoeheWagen=hoeheStab/10
    val breiteWagen= hoeheStab/5

    val zeitText = stage.text("$zeit s")
    zeitText.y=600.0
    zeitText.x= 500.0
    zeitText.fontSize=30.0

   val generationText= stage.text("Netzwerk $generation")
    generationText.y= 650.0
    generationText.x= 500.0
    generationText.fontSize=30.0

    /** Die drei Körper werden zur Visualisierung als SolidRect erstellt.
     *  Da die Rechtecke nicht auf die Physik der Box 2d reagieren sollen wird ihr Type auf „STATIC“ gesetzt.
     *  Die unterschiedliche Färbung dient der Unterscheidung.
     *  Die negative Höhe des Stabs geht daraus hervor, dass der Referenzpunkt eines Rechtecks hier seine obere linke Ecke ist, der Stab jedoch an seinem unteren Ende am Wagen befestigt ist.
     *  Den Bodies wird am Ende jeder Iteration der while-Schleife, also 50 mal pro Sekunde, die Orts- und Ausrichtungswerte von Stab und Wagen übertragen:**/

    val cart = stage.solidRect(breiteWagen, hoeheWagen).apply {
        position(250, 1000)
        rotation(Angle(0.0))
        color=Colors.RED
        registerBodyWithFixture(type = BodyType.STATIC,friction = 0.00,fixedRotation = true)

    }
    val pole= stage.solidRect(breiteStab, -hoeheStab).apply {
        position(250, 1000)
        rotation(Angle(0.0) )
        registerBodyWithFixture(type = BodyType.STATIC,friction = 0.01)
        color=Colors.BLUE
    }
    val pole2= stage.solidRect(breiteStab, -hoeheStab/10).apply {
        position(240, 1000)
        rotation(Angle(0.0) )
        registerBodyWithFixture(type = BodyType.STATIC,friction = 0.01)
        color=Colors.GREENYELLOW
    }

    var aBewegungen=0

    /**Der Versuch wird so lange simuliert, bis die Abbruchkriterien überschritten werden**/
    while(wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && stab2Rotation<drehGrenze && stab2Rotation>-drehGrenze&& aBewegungen<500000){

        delay(TimeSpan(20.0))

    /** bevor die Werte dem Netz gegeben werden werden sie auf [-1;1] normiert**/
    val wagenXtmp = wagenX/2.4
        val wagenVtmp=wagenV/7.0
        val stabRotationtmp=stabRotation/36.0
        val stabWinkelgeschwindigkeittmp=stabWinkelgeschwindigkeit/20.0
        val stab2Rotationtmp=stab2Rotation/36.0
        val stab2Winkelgeschwindigkeittmp = stab2Winkelgeschwindigkeit/20.0


        var angewendeteKraft: Double

      /** Das Netz bekommt die Werte übergeben und berechnet den Output**/
        var output:DoubleArray

        /**Hier wird unterschieden ob der Versuch mit oder ohne Geschwindigkeitsinformationen gefragt ist**/
       if(geschwindigkeitsInformationen){
        output = netz.rechnen(
            doubleArrayOf(
                wagenXtmp,
                wagenVtmp,
                stabRotationtmp,
                stabWinkelgeschwindigkeittmp,
                stab2Rotationtmp,
                stab2Winkelgeschwindigkeittmp
            )
        )
       }
        else{
            output = netz.rechnen(
               doubleArrayOf(
                   wagenXtmp,
                   stabRotationtmp,
                   stab2Rotationtmp,
               )
           )
       }

        /** Abhängig vom Output  erhält die Kraft den Vorfaktor + oder - **/
        angewendeteKraft = if (output[0]==0.0) kraft
        else -kraft

        /** Runge-Kutta Verfahren 4.Ordnung
         * die Orts- und Geschwindigkeitswerte für den Nächsten Zeitschritt werden Berechnet**/

        var vTmp: Double
        var rot1Tmp: Double
        var rot2Tmp: Double
        var vRot1Tmp: Double
        var vRot2Tmp: Double

        /**1. Schritt**/

        val stabEffektiveKraft1= stabEffektiveKraft(stabMasse,stabHalbeLaenge,stabWinkelgeschwindigkeit,stabRotation,stabReibung,g)
        val stab2EffektiveKraft1= stabEffektiveKraft(stab2Masse,stab2HalbeLaenge,stab2Winkelgeschwindigkeit,stab2Rotation,stabReibung,g)
        val stabEffektiveMasse1= stabEffektiveMasse(stabMasse,stabRotation)
        val stab2EffektiveMasse1= stabEffektiveMasse(stab2Masse,stab2Rotation)
        val wagenA1= beschleunigung(angewendeteKraft,reibungscoeffizient,wagenV,stab2EffektiveKraft1,stabEffektiveKraft1,wagenMasse,stab2EffektiveMasse1,stabEffektiveMasse1)
        val stabWinkelbeschleunigung1 = winkelbeschleunigung(stabHalbeLaenge, wagenA1, stabRotation, g, stabReibung, stabWinkelgeschwindigkeit, stabMasse)
        val stab2Winkelbeschleunigung1 = winkelbeschleunigung(stab2HalbeLaenge, wagenA1, stab2Rotation, g, stabReibung, stab2Winkelgeschwindigkeit, stab2Masse)
        val wagenV1 = wagenV
        val stabWinkelgeschwindigkeit1= stabWinkelgeschwindigkeit
        val stab2Winkelgeschwindigkeit1= stab2Winkelgeschwindigkeit



        vTmp = wagenV + 0.5*zeitschritt*wagenA1

        rot1Tmp = stabRotation + 0.5*zeitschritt*stabWinkelgeschwindigkeit1
        vRot1Tmp = stabWinkelgeschwindigkeit + 0.5*zeitschritt*stabWinkelbeschleunigung1

        rot2Tmp= stab2Rotation+ 0.5*zeitschritt*stab2Winkelgeschwindigkeit1
        vRot2Tmp =stab2Winkelgeschwindigkeit+ 0.5*zeitschritt*stab2Winkelbeschleunigung1

        /**2. Schritt**/
        val stabEffektiveKraft2= stabEffektiveKraft(stabMasse,stabHalbeLaenge,vRot1Tmp,rot1Tmp,stabReibung,g)
        val stab2EffektiveKraft2= stabEffektiveKraft(stab2Masse,stab2HalbeLaenge,vRot2Tmp,rot2Tmp,stabReibung,g)
        val stabEffektiveMasse2= stabEffektiveMasse(stabMasse,rot1Tmp)
        val stab2EffektiveMasse2= stabEffektiveMasse(stab2Masse,rot2Tmp)
        val wagenA2= beschleunigung(angewendeteKraft,reibungscoeffizient,vTmp,stab2EffektiveKraft2,stabEffektiveKraft2,wagenMasse,stab2EffektiveMasse2,stabEffektiveMasse2)
        val stabWinkelbeschleunigung2 = winkelbeschleunigung(stabHalbeLaenge, wagenA2, rot1Tmp, g, stabReibung, vRot1Tmp, stabMasse)
        val stab2Winkelbeschleunigung2 = winkelbeschleunigung(stab2HalbeLaenge, wagenA2, rot2Tmp, g, stabReibung, vRot2Tmp, stab2Masse)
        val wagenV2 = vTmp
        val stabWinkelgeschwindigkeit2= vRot1Tmp
        val stab2Winkelgeschwindigkeit2= vRot2Tmp


        vTmp = wagenV + 0.5*zeitschritt*wagenA2

        rot1Tmp = stabRotation + 0.5*zeitschritt*stabWinkelgeschwindigkeit2
        vRot1Tmp = stabWinkelgeschwindigkeit + 0.5*zeitschritt*stabWinkelbeschleunigung2

        rot2Tmp= stab2Rotation+ 0.5*zeitschritt*stab2Winkelgeschwindigkeit2
        vRot2Tmp =stab2Winkelgeschwindigkeit+ 0.5*zeitschritt*stab2Winkelbeschleunigung2

        /**3. Schritt**/
        val stabEffektiveKraft3= stabEffektiveKraft(stabMasse,stabHalbeLaenge,vRot1Tmp,rot1Tmp,stabReibung,g)
        val stab2EffektiveKraft3= stabEffektiveKraft(stab2Masse,stab2HalbeLaenge,vRot2Tmp,rot2Tmp,stabReibung,g)
        val stabEffektiveMasse3= stabEffektiveMasse(stabMasse,rot1Tmp)
        val stab2EffektiveMasse3= stabEffektiveMasse(stab2Masse,rot2Tmp)
        val wagenA3= beschleunigung(angewendeteKraft,reibungscoeffizient,vTmp,stab2EffektiveKraft3,stabEffektiveKraft3,wagenMasse,stab2EffektiveMasse3,stabEffektiveMasse3)
        val stabWinkelbeschleunigung3 = winkelbeschleunigung(stabHalbeLaenge, wagenA3, rot1Tmp, g, stabReibung, vRot1Tmp, stabMasse)
        val stab2Winkelbeschleunigung3 = winkelbeschleunigung(stab2HalbeLaenge, wagenA3, rot2Tmp, g, stabReibung, vRot2Tmp, stab2Masse)
        val wagenV3 = vTmp
        val stabWinkelgeschwindigkeit3= vRot1Tmp
        val stab2Winkelgeschwindigkeit3= vRot2Tmp


        vTmp = wagenV + zeitschritt*wagenA3

        rot1Tmp = stabRotation + zeitschritt*stabWinkelgeschwindigkeit3
        vRot1Tmp = stabWinkelgeschwindigkeit + zeitschritt*stabWinkelbeschleunigung3

        rot2Tmp= stab2Rotation+ zeitschritt*stab2Winkelgeschwindigkeit3
        vRot2Tmp =stab2Winkelgeschwindigkeit+ zeitschritt*stab2Winkelbeschleunigung3

        /**4. Schritt**/
        val stabEffektiveKraft4= stabEffektiveKraft(stabMasse,stabHalbeLaenge,vRot1Tmp,rot1Tmp,stabReibung,g)
        val stab2EffektiveKraft4= stabEffektiveKraft(stab2Masse,stab2HalbeLaenge,vRot2Tmp,rot2Tmp,stabReibung,g)
        val stabEffektiveMasse4= stabEffektiveMasse(stabMasse,rot1Tmp)
        val stab2EffektiveMasse4= stabEffektiveMasse(stab2Masse,rot2Tmp)
        val wagenA4= beschleunigung(angewendeteKraft,reibungscoeffizient,vTmp,stab2EffektiveKraft4,stabEffektiveKraft4,wagenMasse,stab2EffektiveMasse4,stabEffektiveMasse4)
        val stabWinkelbeschleunigung4 = winkelbeschleunigung(stabHalbeLaenge, wagenA4, rot1Tmp, g, stabReibung, vRot1Tmp, stabMasse)
        val stab2Winkelbeschleunigung4 = winkelbeschleunigung(stab2HalbeLaenge, wagenA4, rot2Tmp, g, stabReibung, vRot2Tmp, stab2Masse)
        val wagenV4 = vTmp
        val stabWinkelgeschwindigkeit4= vRot1Tmp
        val stab2Winkelgeschwindigkeit4= vRot2Tmp


        wagenV += (wagenA1 + (wagenA2 + wagenA3) * 2.0 + wagenA4) * zeitschritt/6.0
        wagenX += (wagenV1 + (wagenV2 + wagenV3) * 2.0 + wagenV4) * zeitschritt/6.0
        stabWinkelgeschwindigkeit += (stabWinkelbeschleunigung1 + (stabWinkelbeschleunigung2 + stabWinkelbeschleunigung3) * 2.0 + stabWinkelbeschleunigung4) * zeitschritt/6.0
        stab2Winkelgeschwindigkeit += (stab2Winkelbeschleunigung1 + (stab2Winkelbeschleunigung2 + stab2Winkelbeschleunigung3) * 2.0 + stab2Winkelbeschleunigung4) * zeitschritt/6.0
        stabRotation += (stabWinkelgeschwindigkeit1 + (stabWinkelgeschwindigkeit2 + stabWinkelgeschwindigkeit3) * 2.0 + stabWinkelgeschwindigkeit4)* zeitschritt/6.0
        stab2Rotation += (stab2Winkelgeschwindigkeit1 + (stab2Winkelgeschwindigkeit2 + stab2Winkelgeschwindigkeit3) * 2.0 + stab2Winkelgeschwindigkeit4) * zeitschritt/6.0

        aBewegungen++
        zeit+= zeitschritt


        /** Zeitvisualisierung updaten **/
        zeitText.text="$zeit s"

        /** die berechneten Werte werden zur Visualisierung den Bodies übertragen **/
            pole.rotation=Angle(stabRotation)
            pole.x=vergroesserungsFaktor*(wagenX+2.4)
            pole2.rotation= Angle(stab2Rotation)
            pole2.x=vergroesserungsFaktor*(wagenX+2.4)-10
            cart.x=vergroesserungsFaktor*(wagenX+2.4)-0.5*breiteWagen
            zeit+= zeitschritt
        }

/** Objekte von der Stage entfernen**/
    stage.removeChildren()
    netz.fitness= aBewegungen.toDouble()
}

/** Bewegungsformeln**/
fun winkelbeschleunigung(stabHalbeLaenge:Double, wagenA:Double,stabRotation:Double,g:Double,stabReibung:Double,stabWinkelgeschwindigkeit:Double,stabMasse:Double)=-1.0*(3.0/(4.0*stabHalbeLaenge))*(wagenA *cos(stabRotation)+ g*sin(stabRotation)+(stabReibung*stabWinkelgeschwindigkeit)/(stabMasse*stabHalbeLaenge))
fun beschleunigung(angewendeteKraft:Double,reibungscoeffizient:Double,wagenV:Double,stab2EffektiveKraft:Double, stabEffektiveKraft:Double, wagenMasse:Double,stab2EffektiveMasse: Double,stabEffektiveMasse:Double)  =(angewendeteKraft-reibungscoeffizient*sign(wagenV)+stabEffektiveKraft+stab2EffektiveKraft)/(wagenMasse+stab2EffektiveMasse+stabEffektiveMasse)
fun stabEffektiveKraft(stabMasse: Double,stabHalbeLaenge: Double,stabWinkelgeschwindigkeit: Double,stabRotation: Double,stabReibung: Double,g: Double)=stabMasse*stabHalbeLaenge*stabWinkelgeschwindigkeit*stabWinkelgeschwindigkeit*sin(stabRotation)+ (3.0/4.0)*stabMasse* cos(stabRotation)*(((stabReibung*stabWinkelgeschwindigkeit)/(stabMasse*stabHalbeLaenge))+g*sin(stabRotation))
fun stabEffektiveMasse(stabMasse: Double,stabRotation: Double)= stabMasse*(1.0-(3.0/4.0)*cos(stabRotation).pow(2.0))
