import kotlin.math.exp
import kotlin.random.Random
/**Objekte dieser Klasse können ein Feed-Forward-Netz jeglicher Topologie speichern (var netz), diese rechnen lassen (fun rechnen) und ausgeben (fun print) **/
class Netzwerk(var schichten : Array<Int>, var fitness:Double=0.0) {
    /**
   das eigentliche Netz als zweidimesionales Neuronenarray**/
    var netz = Array(schichten.size - 1) { i ->
        Array(schichten[i]) {
            Neuron(DoubleArray(schichten[i + 1]) {
                (Random.nextDouble() - 0.5) * 5
            }, 0.0, (Random.nextDouble() - 0.5) * 5)
        }
    }
    /** berechnet mit Matrixmultiplikation die Ausgabewerte
     * der InputArray muss gleich groß sein wie die Anzahl der Inputneuronen**/
    fun rechnen(Input: DoubleArray): DoubleArray {

        for (a in 0 until schichten[0]) {
            netz[0][a].wert = Input[a]
        }
        for (schicht in 1 until netz.size) {
            for (neuron in netz[schicht].indices) {
                var tmp = 0.0
                for (neuronVorgaenger in netz[schicht - 1].indices) {
                    tmp += netz[schicht - 1][neuronVorgaenger].wert * netz[schicht - 1][neuronVorgaenger].synapsen[neuron]
                }
                netz[schicht][neuron].wert = ReLU(tmp + netz[schicht][neuron].bias)
            }
        }
        /** Doublearray der je Outputneuron ein Double enthält.
         *  dadurch dass der Output einzeln berecnet wird, lässt sich hier eine andere Aktivierunsfunktion als in den versteckten Schichten anwenden, wenn so gewollt**/
        val output = DoubleArray(schichten.last()) { 0.0 }
        for (outputNeuron in output.indices) {
            var tmp = 0.0
            for (i in netz.last().indices) {
                tmp += netz.last()[i].wert * netz.last()[i].synapsen[outputNeuron]
            }
            output[outputNeuron] = ReLU(tmp)
        }
        return output
    }
    /** gibt die Netwerkwerte in der Konsole aus**/
    fun print() {

        for (a in netz.indices) {
            print("Schicht $a:")

            for (b in netz[a].indices) {

                print("Neuron $b ")
                print("(")
                print(netz[a][b].bias)
                print(",")
                for (c in netz[a][b].synapsen.indices) {
                    print(netz[a][b].synapsen[c])
                    print(" ")
                }
                print(")")
            }
            println()
        }
    }

}

 /** Aktivierungfunktionen**/
fun ReLU (Input : Double) : Double {
    return if(Input>0) Input
    else 0.0
}
fun Sigmoid (Input : Double) : Double {

    return  1.0 / ( 1.0 + exp( -Input ) )
}