/**Klasse Neuron:
 * synapsen: alle Synapsengewichte der Synapsen von diesem Neuron ausgehen zu jedem neuron der nächsten Schicht
 * wert: Aktivierungswert des Neurons
 * bias: Bias des Neurons**/

class Neuron (var synapsen: DoubleArray, var wert : Double, var bias : Double)
