import kotlin.random.Random
/**führt einen kompletten Evolutionschritt mit Evalution, Selektion, Reproduktion und Mutation durch**/
fun evolution(
    population: Array<Netzwerk>, achild:Int,
    mutationRate: Double, selektionsfaktor: Double = 0.1, geschwindigkeitsInformationen:Boolean) : Array<Netzwerk> {

    /** 1.Evaluation: Fitness jeder Netzwerks herausfinden**/

for(i in population){
 fitnessFunktion2(i,geschwindigkeitsInformationen)
}


    /** 2.Selektion: Die fittesten Netzwerke auswählen.**/
    population.sortByDescending{ it.fitness }

    /**speichert Parentalnetze in Array**/
    val eltern= Array<Netzwerk>((achild*selektionsfaktor).toInt()){i ->population[i]}



  //println(eltern[0].fitness.toInt())

    /** 3.Reproduktion und Mutation: Eine neue Population erstellen und diese mit mutierten Kindern der besten Netzwerke füllen.**/

    val neuePopulation: Array<Netzwerk> = Array<Netzwerk>(population.size) { Netzwerk(population[0].schichten) }

     for(netzwerk in eltern.indices) {
         for (aaa in 0..achild/eltern.size - 2) {
             neuePopulation[netzwerk*achild/eltern.size+aaa].netz = Array(population[netzwerk].schichten.size - 1) { i ->
                 Array(population[netzwerk].schichten[i]) { j ->
                     Neuron(
                         DoubleArray(population[netzwerk].schichten[i + 1]) { k -> population[netzwerk].netz[i][j].synapsen[k] +    (Random.nextDouble() - 0.5) * mutationRate/population[netzwerk].fitness +0.01},
                         0.0,
                         population[netzwerk].netz[i][j].bias +   (Random.nextDouble() - 0.5)  *mutationRate/population[netzwerk].fitness+0.01 ,
                     )
                 }


             }
             /**die Parentalnetze werden in die Nächste Generation unverändert übernommen um eine Verschlechterung zu vermeiden**/
             neuePopulation[(netzwerk + 1) * achild / population.size - 1].netz =
                 Array(population[netzwerk].schichten.size - 1) { i ->
                     Array(population[netzwerk].schichten[i]) { j ->
                         Neuron(
                             DoubleArray(population[netzwerk].schichten[i + 1]) { k -> population[netzwerk].netz[i][j].synapsen[k] },
                             0.0,
                             population[netzwerk].netz[i][j].bias
                         )
                     }
                 }
         }}
    /**neue Population zurückgeben**/
     return neuePopulation


 }

