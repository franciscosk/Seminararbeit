

import com.soywiz.kds.Queue
import kotlin.math.*
 suspend fun main() {
	 /** Population erstellen:
	  * Netwerk-Arraygröße = Anzahl der Netzwerke in einer Population
	  * das IntArray ist für die Netztopologie zuständing:
	  * jeder zahl repräsentiert eine Schicht, ihr Wert die Anzahl der Neuronen der Schicht
	  * die erste Zahl (links) steht für die Inputschicht, die letzte (rechts) für die Outputschicht
	  **/
	 var population1 = Array<Netzwerk>(100) { Netzwerk(arrayOf(6,10,1)) }
	 var selektionsfaktor = 0.08
	 var mutationsrate = 500.0
	 var evolutionsschritte = 10

	 /** Lerndaten erheben:**/
	//var evolutionsdaten= evolutionSchrittePro(10,geschwindigkeitsInformationen = true)
	 /** daten ausgeben**/
	 /*for (i in evolutionsdaten){
	 	for (a in i){
	 		println(punktZuKomma(a))

		 println()
		 println()
	 }*/


	 //fitness2Visuell(evolutionAbbruchkriteriumPro(100000.0,population1,mutationsrate,population1.size,selektionsfaktor,true),true)

optimierung()
}
	 /*for(i in verbessertePopulation){
		fitnessFunktion2(i)

	}
	verbessertePopulation.sortByDescending { it.fitness }

	 fitness2Visuell(verbessertePopulation)
}*/


	 /*var temp = 0.0
	 repeat(100){
		 var population = Array<Netzwerk>(100) { Netzwerk(arrayOf(6, 10, 1)) }
	 	temp+= evolutionAbbruchkriterium(100000.0,population,mut,population.size,sel)

	 }
	 temp/=100
	 println("avg gen: $temp")
*/



/** Führt von einer Initialpopulation (var startPopulation) ausgehend eine vorgegebene Menge (var schritte) an Evolutionsschritten durch.
 *  populationsGroesse: Anzahl der Netze in der Population
 **/
fun evolutionSchritte( schritte:Int, startPopulation: Array<Netzwerk>,mutationsRate:Double= 100.00, populationsGroesse: Int= 100,selektionsfaktor: Double, geschwindigkeitsInformationen: Boolean):Array<Netzwerk>{

	var population= startPopulation
	for ( i in 0 until schritte){

		var neuepopulation =  evolution(population,populationsGroesse,mutationsRate,selektionsfaktor,geschwindigkeitsInformationen)
		population= neuepopulation
	}
	return population
}

/** erhebt Lerngeschwindgkeitsdaten
 * ausgegeben wird eine Mutablelist 3 Mutable Lists der Größe var schritte
 *   1.Liste: durchnittliche Bestfitnneswerte jeder Generation 0 bis schritte
 *   2.Liste: durchschnittliche durchschnittfitnesswerte jeder Generation 0 bis schritte
 *   3.Liste: durchschnittliche Minimalfitnesswerte jeder Generation 0 bis Schritte
 *   **/
fun evolutionSchrittePro( schritte:Int,mutationsRate:Double= 1000.00, populationsGroesse: Int= 100, selektionsfaktor: Double=0.05, geschwindigkeitsInformationen: Boolean): MutableList<MutableList<Double>> {
	var populationen = 25
	var populationsListe = mutableListOf<Array<Netzwerk>>()
	var bestfitnessListe= mutableListOf<Double>()
	var avgFitnessList= mutableListOf<Double>()
	var worstFitnessList= mutableListOf<Double>()
	repeat(populationen) {
		var neuePopulation = Array<Netzwerk>(100) { Netzwerk(arrayOf(6, 10, 1)) }
		populationsListe.add(neuePopulation)
	}

	for (a in 0..schritte) {
		var fortschritt= a.toDouble()/schritte.toDouble()*100.0
		println("fortschritt: $fortschritt%")
		var avgFitness=0.0
		var bestFitness=0.0
		var worstFitness=0.0
		for ( a in populationsListe.indices) {
			var population = populationsListe[a]
			for (i in population) {
				fitnessFunktion2(i,geschwindigkeitsInformationen )
			}
			population.sortByDescending { it.fitness }
			bestFitness += population[0].fitness
			worstFitness += population.last().fitness
			for (i in population) {
				avgFitness += i.fitness
			}
			var neuepopulation = evolution(population, populationsGroesse, mutationsRate, selektionsfaktor,geschwindigkeitsInformationen)
			populationsListe[a]= neuepopulation
		}
		avgFitness /= (populationsGroesse*populationsListe.size)
		bestFitness/= populationsListe.size
		worstFitness/=populationsListe.size

		bestfitnessListe.add(bestFitness)
		worstFitnessList.add(worstFitness)
		avgFitnessList.add(avgFitness)

		}
	var gesamtdaten = mutableListOf<MutableList<Double>>()
	gesamtdaten.add(bestfitnessListe)
	gesamtdaten.add(worstFitnessList)
	gesamtdaten.add(avgFitnessList)
	return (gesamtdaten)
	}

/** führt Neuroevolution durch bis bestimmter Fitnesswert durch Populationsbesten erreicht ist
 *  zurückgegeben wird die benötigte Anzahl an Generationen**/
fun evolutionAbbruchkriterium(fitness:Double, startPopulation: Array<Netzwerk>,mutationsRate:Double= 100.00, populationsGroesse: Int= 100, selektionsfaktor: Double,geschwindigkeitsInformationen: Boolean): Int {

	var generationen = 0
	var neustarts=0
	var population= startPopulation
	var bestfitness= 0.0
	var letzteFitness=0.0
	var keineVerbesserung=0

	while(fitness>bestfitness){
        generationen++

		var neuepopulation =  evolution(population,populationsGroesse,mutationsRate,selektionsfaktor,geschwindigkeitsInformationen)
		population= neuepopulation

		for(i in population){
			fitnessFunktion2(i,geschwindigkeitsInformationen)
		}
		letzteFitness=bestfitness
		population.sortByDescending { it.fitness }

		bestfitness= population[0].fitness
		if(bestfitness<=letzteFitness)keineVerbesserung++
		else keineVerbesserung=0


	}
	return generationen
}

/** führt Neuroevolution durch bis bestimmter Fitnesswert durch Populationsbesten erreicht ist.
 * gibt Array mit je Populationsbestem Netz jeder Generation zurück, welche dann mit fun fitness2Visuell visualisiert werden können**/
suspend fun evolutionAbbruchkriteriumPro(fitness:Double, startPopulation: Array<Netzwerk>, mutationsRate:Double= 100.00, populationsGroesse: Int= 100, selektionsfaktor: Double,geschwindigkeitsInformationen:Boolean): Array<Netzwerk> {

	var besteNetze= mutableListOf<Netzwerk>()

	var population= startPopulation
	var bestfitness= 0.0
	while(fitness>bestfitness){

		for(i in population){
			fitnessFunktion2(i,geschwindigkeitsInformationen)
		}
		population.sortByDescending { it.fitness }
		bestfitness= population[0].fitness
		besteNetze.add(population[0])

		println(bestfitness)
		var neuepopulation =  evolution(population,populationsGroesse,mutationsRate,selektionsfaktor,geschwindigkeitsInformationen)
		population= neuepopulation
	}
	var bestar= Array<Netzwerk>(besteNetze.size){i -> besteNetze[i]}
	return bestar
}

/** Werteoptimierung von Selektionsfaktor und Mutationsrate**/
fun optimierung() {

	var mutationsrate: Double
	val populationsGroesse = 100
	val mutArray = arrayOf (200.0,500.0,1000.0,2000.0)
	val selArray = doubleArrayOf(0.5,0.8,1.0,2.0,5.0)
	var selektionsFaktor = 0.1



			for(a in selArray){
				selektionsFaktor= 0.1*a
				println("selektionfaktor: $selektionsFaktor")
				for( i in mutArray){
					mutationsrate= i



		var generationen= 0.0
		repeat(50) {
			val population = Array<Netzwerk>(populationsGroesse) { Netzwerk((arrayOf(6, 10, 1)))}
			generationen += evolutionAbbruchkriterium(100000.0,population,mutationsrate,populationsGroesse,selektionsFaktor,true )
		}
	val avgFitness= generationen/50
println(punktZuKomma(avgFitness))
				}
			}
	println("fertig")
}

/** erleichtert die Arbeit mit Tabellenkalkulationsprogrammen, tauscht jeden Punkt durch ein Komma aus**/
fun punktZuKomma(i:Double):String{
	var string = i.toString()
	var ruString:String=""
	for (a in string.indices){
		if (string[a]=='.') {
			 ruString+=','}
		else ruString+= string[a]
	}
	return ruString
}


